
/**
 * Module dependencies.
 */

var express = require('express')
  , routes = require('./routes')
  , user = require('./routes/user')
  , http = require('http')
  , path = require('path')
  , passport = require('passport')
  , flash = require('connect-flash')
  , cookieParser = require('cookie-parser')
  , bodyParser = require('body-parser')
  , session = require('express-session')
  , mongoose = require('mongoose')
  , configDB = require('./config/mongoconn.js');

mongoose.connect(configDB.url);

var app = express();

// all environments
app.set('port', process.env.PORT || 8000);
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');
app.use(express.favicon());
app.use(express.logger('dev'));
app.use(cookieParser());
app.use(bodyParser.urlencoded({
	  extended: true
}));
app.use(express.methodOverride());
app.use(app.router);
app.use(express.static(path.join(__dirname, 'public')));

app.use(session({ secret: 'uberapp',
                  resave: true,  // forces the session to store every time, even when no session data has been modified with the request 
                  saveUninitialized: true})); // session secret
app.use(passport.initialize());
app.use(passport.session()); // persistent login sessions
app.use(flash());


// development only
if ('development' == app.get('env')) {
  app.use(express.errorHandler());
}

var homeRoute = require('./routes/homeRouteConfig.js');
new homeRoute(app, passport);

http.createServer(app).listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('port'));
});
