var mq_client = require('../rpc/client');

function homeRouteConfig(app,passport){
	
	this.app=app;
	this.passprt=passport;
	this.routeTable= [];
	this.init();
}

homeRouteConfig.prototype.init = function(){
	
	var self = this;
	this.addRoutes();
	this.processRoutes();
}


homeRouteConfig.prototype.processRoutes = function(){
	
	var self = this;
	self.routeTable.forEach(function(route){
		
		if(route.requestType == 'get'){
			self.app.get(route.requestUrl,route.callbackFunction);
		}
		else if(route.requestType == 'post'){
			self.app.post(route.requestUrl,route.callbackFunction);
		}
		
	});
}

homeRouteConfig.prototype.addRoutes = function(){
	
	var self =  this;
	
    self.routeTable.push({
		
		requestType : 'get',
	    requestUrl  : '/',
	    callbackFunction : function (request,response){
	    	response.render('index', { title: 'Express' });
	    }
	});
    
    self.routeTable.push({
		
		requestType : 'get',
	    requestUrl  : '/loginPage',
	    callbackFunction : function (request,response){
	    	response.render('login_page');
	    }
	});
    
    self.routeTable.push({
		
		requestType : 'get',
	    requestUrl  : '/riderloginPage',
	    callbackFunction : function (request,response){
	    	response.render('login_rider');
	    }
	});
    
    self.routeTable.push({
		
		requestType : 'get',
	    requestUrl  : '/driverloginPage',
	    callbackFunction : function (request,response){
	    	response.render('login_driver');
	    }
	});
    
 self.routeTable.push({
		
		requestType : 'get',
	    requestUrl  : '/riderLogin',
	    callbackFunction : function (request,response){
	    	response.render('rider_login');
	    }
	});
    
    self.routeTable.push({
		
		requestType : 'get',
	    requestUrl  : '/driverLogin',
	    callbackFunction : function (request,response){
	    	response.render('driver_login');
	    }
	});
    
self.routeTable.push({
		
		requestType : 'get',
	    requestUrl  : '/riderSignupPage',
	    callbackFunction : function (request,response){
	    	response.render('rider_signup');
	    }
	});
    
    self.routeTable.push({
		
		requestType : 'get',
	    requestUrl  : '/driverSignupPage',
	    callbackFunction : function (request,response){
	    	response.render('driver_signup');
	    }
	});
	
	
	
    self.routeTable.push({
		
		requestType : 'post',
	    requestUrl  : '/createPost',
	    callbackFunction : function (request,response){
	    	var msg_payload = {"post" : request.body.post };
	    	mq_client.make_request('create_post_queue',msg_payload, function(err,results){
	    		response.json({status : 'success'});
	    	});
	    }
	});
    
    self.routeTable.push({
		
		requestType : 'get',
	    requestUrl  : '/logout',
	    callbackFunction : function (request,response){
	    	request.logout();
	    	request.redirect('/');
	    }
	});
    
}

function isLoggedIn(req, res, next) {

    // if user is authenticated in the session, carry on 
    if (req.isAuthenticated())
        return next();

    // if they aren't redirect them to the login page
    res.redirect('/');
}

module.exports = homeRouteConfig;